require('dotenv').config();
const mysql = require('mysql');

const config = mysql.createConnection({
    host: 'atp.fhstp.ac.at',
    port: 8007,
    user: 'cc221048',
    //password only visible, because of connection issues with FH server.
    password: 'wC5kVj2fMx!7',
    database: 'cc221048'
});

config.connect(function (err) {
    if(err) throw err;
    console.log('Connected to database');
});

module.exports = {config};

