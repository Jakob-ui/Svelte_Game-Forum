const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const db = require('../services/database').config;

const ACCESS_TOKEN_SECRET = process.env.ACCESS_TOKEN_SECRET;
module.exports = {};

async function authenticateUser({ name, password }, users, res) {
    const user = users.find(u => u.name === name);
    if (user) {
        let doPasswordMatch = await bcrypt.compare(password, user.password);
        if (doPasswordMatch) {
            const accessToken = jwt.sign(
                { id: user.id, name: user.name },
                ACCESS_TOKEN_SECRET,
                { expiresIn: '2h' }
            );

            res.cookie('accessToken', accessToken);
            res.json({ accessToken: accessToken });
        } else {
            res.send('Password incorrect');
        }
    } else {
        res.send('Username not found');
    }
}


async function authenticateJWT(req, res, next) {
    const token = req.cookies['accessToken'];

    if (token) {
        jwt.verify(token, ACCESS_TOKEN_SECRET, (err, user) => {
            if (err) {
                return res.status(403).json({ error: 'Failed to authenticate token' });
            }

            req.user = {};

            db.query('SELECT UserID FROM laschober_wilhelm_user WHERE name = ?', [user.name], function(err, results) {
                if (err) {
                    return res.status(500).json({ error: 'Database error' });
                }
                if (results.length > 0) {
                    // Continue with your code
                } else {
                    return res.status(404).json({ error: 'User not found' });
                }
            });
        })
    } else {
        res.status(401).json({ error: 'No token provided' });
    }
}

module.exports = {authenticateUser, authenticateJWT};