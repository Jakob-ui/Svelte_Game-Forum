const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const userRouter = require('./router/userRouter');
const functionRouter = require('./router/functionRouter');
const cors = require('cors');
const db = require('./services/database');
const authenticationRouter = require('./router/authenticationRouter');
const cookieParser = require('cookie-parser');

const app = express();
const port = 3000;

app.use(cors());
app.use(cookieParser());
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use('/users', userRouter);
app.use('/function', functionRouter);
app.use('/', authenticationRouter);


const filePath = path.join(__dirname, 'Welcome.txt');

app.get('/', (req, res) => {
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            res.status(500).send('Internal Server Error');
            return;
        }

        res.status(200).send(data);
    });
});

app.listen(port, () =>{
    console.log(`Example app listening at http://localhost:${port}`);
});





