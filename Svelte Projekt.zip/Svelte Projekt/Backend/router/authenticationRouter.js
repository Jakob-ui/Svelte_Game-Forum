const express = require('express');
const router = express.Router();
const authenticationService = require('../services/authentication');
const userModel = require('../models/userModel');


router.post('/login', (req, res) => {
    const { name, password } = req.body;
    userModel.getUser(name)
        .then(user => {
            if (!user || user.length === 0) {
                res.status(401).send('User not found');
                return;
            }
            authenticationService.authenticateUser(req.body, user, res);
        })
        .catch(err => res.send(err));
})

router.get('/logout', (req, res) => {
    res.cookie('accessToken', '', {maxAge: 0});
    res.send({success: true});

})

module.exports = router;