const express = require('express');
const router = express.Router();
const jwt = require("jsonwebtoken");
const userModel = require('../models/userModel');
const authenicationService = require('../services/authentication');



router.post('/new', (req, res) => {
    userModel.createUser(req.body)
    .then(() => res.send('User added'))
    .catch(err => res.status(500).send(err));
});

router.use(authenicationService.authenticateJWT);

router.get('/', (req, res) => {
    userModel.getUsers()
        .then(users => res.json(users))
        .catch(err => res.send(err));
});

router.get('/:index', (req, res) => {
    const userIndex = req.params.index;
    userModel.getUser(userIndex)
        .then(user => res.json(user))
        .catch(err => res.send(err))
});

router.get('/:name', async (req, res) => {
    try {
        const user = await userModel.getUserpername(req.params.name);
        if (!user || user.length === 0) {
            return res.status(404).send({ message: 'User not found.' });
        }
        res.json({ name: user[0].id });
    } catch (err) {
        res.status(500).send({ message: 'An error occurred while retrieving the user ID', error: err });
    }
});

router.delete('/me', function (req, res) {
    const token = req.headers['x-access-token'];
    if (!token) {
        return res.status(403).send({ auth: false, message: 'No token provided.' });
    }

    jwt.verify(token, 'your_secret_key', function(err, decoded) {
        if (err) {
            return res.status(500).send({ auth: false, message: 'Failed to authenticate token.' });
        }

        userModel.deleteUser(decoded.id)
            .then(() => res.status(204).end())
            .catch(err => res.status(404).send("User not found."));
    });
});

module.exports = router;