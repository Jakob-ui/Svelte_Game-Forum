const express = require('express');
const router = express.Router();

const functionModel = require('../models/functionModel');


router.post('/newcomment', async (req, res) => {
    try {
        await functionModel.createRating(req, req.body);
        res.send('Rating added');
    } catch (err) {
        res.status(500).send({ message: 'An error occurred while adding your rating', error: err });
    }
    res.end();
});

router.get('/getgametitle', async (req, res) => {
    try {
        const gametitles = await functionModel.getGametitle();
        res.json(gametitles);
    } catch (err) {
        res.status(500).send({ message: 'An error occurred while retrieving the game titles', error: err });
    }
});

router.get('/games/:id', async (req, res) => {
    try {
        const game = await functionModel.getGameById(req.params.id);
        res.json(game);
    } catch (err) {
        console.error(err);
        res.status(500).send('An error occurred while retrieving the game');
    }
});

router.get('/getcomment/:id', async (req, res) => {
    try {
        const rating = await functionModel.getRatingById(req.params.id);
        res.json(rating);
    } catch (err) {
        res.status(500).send({ message: 'An error occurred while retrieving the ratings', error: err });
    }
});

router.post('/newgametitle', async (req, res) => {
    try {
        await functionModel.createGametitles(req, req.body);
        res.send('Title added');
    } catch (err) {
        res.status(500).send({ message: 'An error occurred while adding your game title', error: err });
    }
    res.end();
});





module.exports = router;
