const db = require('../services/database').config;



let getGametitle = () => new Promise((resolve, reject) => {
    try {
        db.query('SELECT * FROM laschober_wilhelm_gametitle', function (err, gametitles, fields) {
            if (err) {
                throw err;
            } else {
                console.log(gametitles);
                resolve(gametitles);
            }
        });
    } catch (err) {
        console.error(err);
        throw new Error('An error occurred while retrieving the game titles from the database');
    }
});

const createGametitles = (req, game) => {
    return new Promise((resolve, reject) => {
        try {
            db.query(`INSERT INTO laschober_wilhelm_gametitle (name, gametitle, link) VALUES ( ?, ?, ?)`, [
                    game.name,
                    game.gametitle,
                    game.link],
                function (err, result) {
                    if (err) {
                        reject(err);
                        console.log("failed");
                    } else {
                        console.log("1 record inserted");
                        resolve(result);
                    }
                }
            );
        } catch (err) {
            console.error(err);
            reject(new Error('An error occurred while adding the game title to the database'));
        }
    });
}

let getRatingById = (id) => new Promise((resolve, reject) => {
    try {
        db.query('SELECT * FROM laschober_wilhelm_bewertung WHERE gameID = ?', [id], function (err, rating, fields){
            if(err) {
                throw err;
            } else {
                resolve(rating);
            }
        });
    } catch (err) {
        console.error(err);
        throw new Error('An error occurred while retrieving the rating from the database');
    }
});

let getGameById = (id) => new Promise((resolve, reject) => {
    try {
        db.query('SELECT * FROM laschober_wilhelm_gametitle WHERE gameID = ?', [id], function (err, game, fields) {
            if (err) {
                throw err;
            } else {
                resolve(game);
            }
        });
    } catch (err) {
        console.error(err);
        throw new Error('An error occurred while retrieving the game from the database');
    }
});

const createRating = async (req, rating) => {
    try {
        db.query(`INSERT INTO laschober_wilhelm_bewertung (gameID, name, bewertung) VALUES (?, ?, ?)`, [
                rating.gameID,
                rating.name,
                rating.bewertung],
            function (err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
        );
    } catch (err) {
        console.error(err);
        throw new Error('An error occurred while adding the rating to the database');
    }
}


module.exports = {createRating, createGametitles, getGametitle, getGameById, getRatingById};
