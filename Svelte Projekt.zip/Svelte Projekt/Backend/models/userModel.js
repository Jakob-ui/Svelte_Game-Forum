const db = require('../services/database').config;
const bcrypt = require('bcrypt');
const jwt = require("jsonwebtoken");

let getUsers = () => new Promise((resolve, reject) => {
    db.query('SELECT * FROM laschober_wilhelm_user', function (err, users, fields) {
        if (err) {
            reject(err);
        } else {
            console.log(users);
            resolve(users);
        }
    })
});

let getUser = async (username) => new Promise((resolve, reject) => {
    db.query('SELECT * FROM laschober_wilhelm_user WHERE name = ?', [username], function (err, user, fields){
        if(err) reject(err);
        else resolve(user);
    })
})

let getUserpername = async (username) => new Promise((resolve, reject) => {
    db.query('SELECT UserID FROM laschober_wilhelm_user WHERE name = ?', [username], function (err, user, fields){
        if(err) reject(err);
        else resolve(user[0].UserID);
    })
})

const createUser = async (userData) => {
    const plainPassword = userData.password;
    const hashedPassword = await bcrypt.hash(plainPassword, 10);
    return new Promise((resolve, reject) => {
        db.query(`INSERT INTO laschober_wilhelm_user (name, email, password) VALUES (?, ?, ?)`, [
            userData.name,
            userData.email,
            hashedPassword], (err, result) => {
            if (err) {
                reject(err);
            } else {
                resolve(result);
            }
        });
    });
}

let deleteUser = async (id) => new Promise((resolve, reject) => {
    db.query('DELETE FROM laschober_wilhelm_user WHERE id = ?', [id], function (err, result){
        if(err) reject(err);
        else resolve(result);
    })
})

    
module.exports = {getUser, getUsers, createUser, deleteUser, getUserpername};


