import {dev} from '$app/environment'

export const title = 'GameDev Proving Ground';
export const description = 'SvelteKit Plattform for GameDevs';
export const url =dev ? 'http://localhost:5173/home' : 'url'