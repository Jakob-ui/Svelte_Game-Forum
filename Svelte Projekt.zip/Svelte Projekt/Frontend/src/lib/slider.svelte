<script lang="ts">

    export let duration: number;
    export let slides: { url: string; description: string }[];
    let currentSlide = 0;

    const nextSlide = () => {
        currentSlide++;
        if (currentSlide >= slides.length) {
            currentSlide = 0;
        }
        timer();
    };

    const prevSlide = () => {
        currentSlide--;
        if (currentSlide < 0) {
            currentSlide = slides.length - 1;
        }
        timer();
    };

    const goToSlide = (i: number) => {
        currentSlide = i;
        timer();
    };

    const timer = () => {
        clearInterval(interval);
        interval = setInterval(nextSlide, duration);
    };

    let interval: number;

    timer();
</script>

<div class="slider">
    {#each slides as { url, description }, i}
        <div class="slide" class:visible={currentSlide === i}>
            <img src={url} alt={description} />
            <p class="description">{description}</p>
        </div>
    {/each}
    <button class="next" on:click={nextSlide}>Next</button>
    <button class="prev" on:click={prevSlide}>Prev</button>
    <div class="nav">
        {#each slides as {}, i}
            <button
                    class="bubble"
                    on:click={() => {
                    goToSlide(i);
                }}
                    class:current={i === currentSlide}
            />
        {/each}
    </div>
</div>

<style>
    .slider {
        position: relative;
        width: 100%;
        height: 100%;
    }

    .slide {
        position: absolute;
        inset: 0;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        opacity: 0; /* initial opacity set to 0 */
        transition: opacity 0.5s ease; /* add opacity transition */
    }

    .slide.visible {
        opacity: 1; /* set opacity to 1 when visible */
    }



    .description {
        margin-top: 10px;
        font-size: 18px;
        text-align: center;
        color: white;
    }

    .next,
    .prev {
        position: absolute;
        z-index: 2;
        top: 50%;
        transform: translateY(-50%);
        background: transparent;
        border: 1px solid #fff;
        color: #fff;
        padding: 4px 10px;
        border-radius: 4px;
        cursor: pointer;
    }

    .next {
        right: 20px;
    }

    .prev {
        left: 20px;
    }

    .nav {
        position: absolute;
        bottom: 20px;
        left: 0;
        right: 0;
        height: 100px;
        z-index: 3;
        display: flex;
        justify-content: space-evenly;
        align-items: center;
    }

    .bubble {
        padding: 0;
        border: 0;
        height: 20px;
        width: 10px;
        border-radius: 100px;
        transition: all 0.3s ease-out;
        opacity: 0.2;
        cursor: pointer;
    }

    .current {
        height: 80px;
        opacity: 0.8;
    }


</style>
