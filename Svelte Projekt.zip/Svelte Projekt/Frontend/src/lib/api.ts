import {goto} from "$app/navigation";

export const login = async (name: string, password: string) => {
    const response = await fetch('http://loacalhost:3000/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, password }),
    });
    if (response.ok) {
        const data = await response.json();
        localStorage.setItem('jwt', data.accessToken);
        localStorage.setItem('username', name);
        await goto('/home')
    } else {
        alert('Wrong username or password');
    }
};

export const postGame = async (gametitle: string, link: string) => {
    const name = localStorage.getItem('username');
    if (!name || !gametitle || !link) {
        alert('Please fill out all fields');
        return;
    }
    try {
        const response = await fetch('http://loacalhost:3000/function/newgametitle', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, gametitle, link }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            console.error('Posting failed', errorData);
            alert('Posting failed - please try again');
        } else {
            console.log('Posted successful');
            console.log({ name, gametitle ,link });
        }
    } catch (error) {
        console.error('An error occurred while posting the [id]', error);
    }
};

export const getgames = async () => {
    const jwt = localStorage.getItem('jwt');
    const response = await fetch('http://loacalhost:3000/function/getgametitle', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${jwt}`
        },
    });
    if (response.ok) {
        const data = await response.json();
        console.log ('get games successful');
        return data;
    }else {
        throw new Error(response.statusText);
    }
}
export const getgame = async (id: bigint) => {
    const jwt = localStorage.getItem('jwt');
    const response = await fetch(`http://loacalhost:3000/function/games/${id}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${jwt}`
        },
    });
    if (response.ok) {
        const data = await response.json();
        console.log (data);
        console.log ('get [id] successful');
        return data;
    }else {
        throw new Error(response.statusText);
    }
}

export const logout = async () => {
    const response = await fetch('http://loacalhost:3000/logout', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        },
    });
    if (response.ok) {
        localStorage.removeItem('jwt');
        localStorage.removeItem('username');
        await goto('./')
    }
}

export const registration = async (name: string, email: string, password: string) => {
    if (!name || !email || !password) {
        alert('Please fill out all fields');
        return;
    }
    const response = await fetch('http://loacalhost:3000/users/new', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, password }),
    });

    if (response.ok) {
        console.log('Registration successful');
        console.log({ name, email, password });
        await goto('./')
    } else {
        console.error('Registration failed');
        alert('Registration failed - please try again');
        console.log({ name, email, password });
    }
};

export const createRating = async (gameID: bigint, bewertung: string) => {
    const name = localStorage.getItem('username');
    if (!name || !gameID || !bewertung) {
        alert('Please fill out all fields');
        return;
    }
    const jwt = localStorage.getItem('jwt');
    const response = await fetch('http://loacalhost:3000/function/newcomment', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${jwt}`
        },
        body: JSON.stringify({ name, gameID: gameID.toString(), bewertung })
    });
    if (response.ok) {
        console.log('Rating added successfully');
    } else {
        const errorData = await response.json();
        console.error('An error occurred while adding the rating', errorData);
    }
};

export const getRatings = async (id: bigint) => {
    const jwt = localStorage.getItem('jwt');
    const response = await fetch(`http://loacalhost:3000/function/getcomment/${id}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${jwt}`
        },
    });
    if (response.ok) {
        const data = await response.json();
        console.log('Comments retrieved successfully');
        return data;
    } else {
        throw new Error(response.statusText);
    }
};
