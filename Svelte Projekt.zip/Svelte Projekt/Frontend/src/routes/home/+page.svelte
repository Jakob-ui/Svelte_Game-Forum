<script lang="ts">
    import { postGame } from "$lib/api.js";
    import { onMount } from 'svelte';
    import { slide } from 'svelte/transition';
    import { getgames } from '$lib/api.js';

    let gametitle = '';
    let link = '';
    interface Game {
        gameID: number;
        name: string;
        gametitle: string;
        link: string;
    }
    let games: Game[] = [];

    const handlenewGame = async () => {
        await postGame(gametitle, link);
        showForm = !showForm;
        await loadGames();
    }


    const loadGames = async () => {
        try {
            games = await getgames();
        } catch (error) {
            console.error('Failed to load games:', error);
        }
    }

    onMount(async () => {
        const jwt = localStorage.getItem('jwt');
        if (!jwt) {
            alert('You are not logged in!');
            window.location.href = '/';
        }
        await loadGames();
    });

    let showForm = false;

    const toggleForm = () => {
        showForm = !showForm;
    };
</script>
<div class="parent">
<h1>Home</h1>
    <section>
        <h3>Willkommen auf GameDev Proving Ground</h3>
        <p>
            Erschaffe, teile und erkunde faszinierende Spielwelten mit unserer leistungsstarken GameDev-Plattform.
            Hier kannst du deine eigenen Spiele direkt über WebGL-Links hochladen und mit der Community teilen.
            Spiele anderer Entwickler warten darauf, von dir getestet zu werden!
        </p>
    </section>

    <section>
        <h4>Funktionen</h4>
        <ul>
            <li>Upload von WebGL-Spielen: <br>
                Lade deine eigenen Spiele hoch, die direkt über WebGL-Links spielbar sind.
                Teile deine Kreationen mit der Welt und erhalte Feedback von der Community.</li>
            <li>Spiele Testen: <br>
                Entdecke eine Vielzahl von Spielen, die von anderen Entwicklern hochgeladen wurden.
                Spiele sie direkt im Browser und erlebe die Vielfalt der Spielideen.</li>
            <li>Benutzerkommentare: <br>
                Hinterlasse Kommentare zu den Spielen, die du ausprobiert hast.
                Teile deine Gedanken, Tipps und Anregungen mit anderen Entwicklern und Spielerinnen.</li>
        </ul>
    </section>

    <button on:click={toggleForm}>
        {#if showForm}
            Close
        {:else}
            Post a new Game
        {/if}
    </button>

    {#if showForm}
        <section transition:slide>
            <form on:submit|preventDefault={handlenewGame}>
                <label for="title">Title:</label>
                <input type="text" id="title" bind:value={gametitle} />
                <label for="link">Link:</label>
                <input type="url" id="link" bind:value={link} />
                <button type="submit">Post</button>
            </form>
        </section>
    {/if}

    <div class="games-grid">
        {#each games as game (game.gameID)}
            <div>
                <img src="/platzhalter.jpg" alt="Game Cover">
                <h2><a href="/home/{game.gameID}">{game.gametitle}</a></h2>
                <p>Creator: {game.name}</p><br>
                <p>Link: <a target="_blank" href="{game.link}">{game.link}</a></p>
            </div>
        {/each}
    </div>





</div>

<style>
    .games-grid div {
        border-bottom: 2px solid #0034fc;
        padding: 100px;
        margin: 30px 0px 20px 0px;
    }
    img {
        width: 100%;
        height: 200px;
        object-fit: cover;
    }
    section {
        margin-bottom: 1rem;
    }

    h1 {
        margin-bottom: 1rem;
    }

    h3 {
        margin-bottom: 0.5rem;
    }

    ul {
        margin-bottom: 0.5rem;
    }

    li {
        margin-bottom: 0.25rem;
    }

    form {
        display: flex;
        flex-direction: column;
    }

    label {
        margin-bottom: 0.25rem;
    }

    input {
        margin-bottom: 0.5rem;
    }
    .parent {
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    h1 {
        text-align: center;
        margin: 20px;
    }
    h2 {
        color: blue;
        text-align: center;
        margin: 20px;
    }
</style>
