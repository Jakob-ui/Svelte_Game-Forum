<script lang="ts">
    import { onMount } from 'svelte';
    import { getgame, createRating, getRatings } from '$lib/api.js';
    import { page } from '$app/stores';
    import { slide } from 'svelte/transition';


    interface Game {
        gameID: number;
        name: string;
        gametitle: string;
        link: string;
    }
    interface Comment {
        id: number;
        name: string;
        gameID: number;
        bewertung: string;
    }

    let id: string = $page.params.id;
    let gameID = id;
    let game: Game;
    let bewertung: string = '';
    let comments: Comment[] = [];
    let showForm = false;

    const toggleForm = () => {
        showForm = !showForm;
    };

    const handlenewComment = async () => {
        await createRating(BigInt(gameID), bewertung);
        bewertung = '';
        showForm = !showForm;
        comments = await getRatings(BigInt(id));

    }


    onMount(async () => {
        console.log('id:', id);
        try {
            const games = await getgame(BigInt(id));
            game = games[0];
            console.log('game:', game);
        } catch (error) {
            console.error('An error occurred while fetching the [id]', error);
        }
        comments = await getRatings(BigInt(id));
    });


</script>
<div class="parent">
<div class="head">
{#if game}
    <h1>Title: {game.gametitle}</h1>
    <img src="/platzhalter.jpg" alt="Game Cover">
    <p>Creator: {game.name}</p><br>
    <p>Link: <a target="_blank" href="{game.link}">{game.link}</a></p><br>
{:else}
    <p>Loading...</p>
{/if}
</div>

<h2>Comments:</h2>

{#each comments.filter(comment => comment.gameID === Number(gameID)) as comment, index (index)}
    <div class="comments">
        <h4>User: {comment.name}</h4>
        <p>Comment: {comment.bewertung}</p>
    </div>
{/each}

    <button on:click={toggleForm}>
        {#if showForm}
            Hide Form
        {:else}
            Show Form
        {/if}
    </button>

{#if showForm}
    <section transition:slide>
        <form on:submit|preventDefault={handlenewComment}>
            <label for="comment">Comment:</label>
            <input type="comment" id="link" bind:value={bewertung} />
            <button type="submit">Post</button>
        </form>
    </section>
{/if}
</div>
<style>
    h1 {
        text-align: center;
        margin-bottom: 40px;
    }
    h2 {
        text-align: center;
        margin: 40px;
    }
    .head{
        display: flex;
        flex-direction: column;
        margin: 20px;
        border-bottom: 2px solid #0034fc;
    }
    .comments{
        display: flex;
        flex-direction: column;
        width: 40em;
        margin: 20px;
        padding: 20px;
        border: 2px solid #0034fc;
        border-radius: 20px;
    }
    .comments h4{
        margin-bottom: 10px;
    }
    .parent{
        display: flex;
        flex-direction: column;
        align-items: center;

    }
</style>