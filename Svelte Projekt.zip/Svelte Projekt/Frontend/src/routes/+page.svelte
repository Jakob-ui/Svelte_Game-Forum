<script>
    import {login} from "$lib/api";

    let name = '';
    let password = '';

    const handleLogin = async () => {
        try {
            await login(name, password);
        } catch (error) {
            alert("password or username incorrect");
        }
    }

</script>


<main>
    <div class="container">
        <div class="header">
            <img src="/logouip.png" alt="Logo of GameDev Proving Ground">
            <h1>GameDev Proving Ground</h1>
            <p>Entfalte dein kreatives Potential und teile deine Spiele mit der Welt! Registriere dich jetzt und werde
                Teil unserer lebendigen GameDev-Community.</p>
        </div>

        <div class="login-section">
            <h2>Login</h2>
            <form on:submit|preventDefault={handleLogin}>
                <label for="name">Name:</label>
                <input bind:value={name} id="name" type="text"/>
                <br>
                <label for="password">Password:</label>
                <input bind:value={password} id="password" type="password"/>
                <br>
                <button type="submit">Login</button>
                <br>
            </form>
            <a href="/registration">Register</a>
        </div>
    </div>
</main>

<style>
    img {
        width: 200px;
        margin-bottom: 50px;
    }
    main {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin-top: 20px;
    }

    .container {
        text-align: -webkit-center;
    }

    .header {
        margin-bottom: 20px;
    }

    h1 {
        font-size: 2em;
        margin-bottom: 10px;
    }

    p {
        font-size: 1.2em;
        color: #666;
    }

    .login-section {
        width: 300px;
        text-align: left;
        margin: 0 auto;
    }

    h2 {
        margin-bottom: 10px;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }

    input {
        width: 100%;
        margin-bottom: 10px;
        padding: 5px;
        box-sizing: border-box;
    }

    button {
        padding: 10px;
        cursor: pointer;
    }
</style>

