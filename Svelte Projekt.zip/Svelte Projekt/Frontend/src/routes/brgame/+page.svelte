<script>
    import { onMount } from 'svelte';
    import Slider from '../../lib/slider.svelte';

    onMount(() => {
        const jwt = localStorage.getItem('jwt');
        if (!jwt) {
            alert('You are not logged in!');
            window.location.href = '/';
        }
    });

    const gameUrl = 'https://mt221095.students.fhstp.ac.at/EIA/';

    const slides = [
        {
            url: './Below.png',
            description: 'Platz 1',
        },
        {
            url: './RadRodgers.png',
            description: 'Platz 2',
        },
        {
            url: './Dungelair.png',
            description: 'Platz 3',
        },
    ];
</script>

<main>
    <div class="container">
        <h1>Best rated Games</h1>
    </div>
    <div class="Slider">
        <Slider
                duration={2000}
                slides={slides}
        />
    </div>
    <div class="gameLink">
        <p>Check out my WebGL game:</p>
        <a href={gameUrl} target="_blank" rel="noopener noreferrer">Play WebGL Game</a>
    </div>
</main>

<style>

    main {
        display: flex;
        flex-direction: column;


    }

    .container {

        text-align: -webkit-center;
        margin-bottom: 60vh;
    }

    .Slider {
        margin-bottom: 70vh;
    }

    .gameLink {
        text-align: -webkit-center;
    }
</style>
