<script lang="ts">
    import * as config from '$lib/config';
    import Toggle from './toggle.svelte';
    import { logout } from "$lib/api.js";
    import {onMount} from "svelte";

    let name = "";
    onMount(async () => {
        name = localStorage.getItem('username') ?? "";
    });

    const handlelogout = async () => {
        await logout();
    }

</script>

<nav>
    <a href="/home" class="title">
        <b>{config.title}</b>
    </a>

    <ul class="links">
        <li>
            <a href="/home">Home</a>
        </li>
        <li>
            <a href="/brgame">Best rated Game</a>
        </li>
    </ul>
    <div class="user">
        <div class="usermessage">
    <img class="personicon" src="/user.png" alt="User Icon">
    <p>Welcome, {name}!</p>
        </div>
    <div class="Buttons">
        <Toggle />
        <button type="submit" on:click={handlelogout}>Logout</button>
    </div>
    </div>

</nav>

<style>
    .personicon{
        width: 20px;
        height: 20px;
    }
    .usermessage{
        display: flex;
        flex-direction: row;
        gap: var(--size-3);
    }
    .user{
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: var(--size-2);
    }
    nav{
        padding-block: var(--size-7);
    }

    .links {
        margin-block: var(--size-7);
    }

    a{
        color: inherit;
        text-decoration: none;
    }

    @media (min-width: 768px) {
        nav {
            display: flex;
            justify-content: space-between;
        }

        .links{
            display: flex;
            gap: var(--size-7);
            margin-block: 0;
        }

        .Buttons {

            display: flex;
            align-items: center;
            gap: var(--size-2);
        }
    }

</style>
