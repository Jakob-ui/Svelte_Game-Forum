<script>

    import {registration} from "$lib/api";

    let name = '';
    let email = '';
    let password = '';

    const handleRegistration = async () => {
        await registration(name, email, password);
    }
</script>

<main>
    <h1>Registration</h1>
    <form on:submit|preventDefault={handleRegistration}>
        <label for="name">Name:</label>
        <input bind:value={name} id="name" type="text"/>
        <br>
        <label for="email">Email:</label>
        <input bind:value={email} id="email" type="email"/>
        <br>
        <label for="password">Password:</label>
        <input bind:value={password} id="password" type="password"/>
        <br>
        <button type="submit">Register</button>
    </form>
</main>

<style>
    main {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin-top: 20px;
    }

    h1 {
        margin-bottom: 60px;
    }

    form {
        width: 300px;
        text-align: left;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }

    input {
        width: 100%;
        margin-bottom: 10px;
        padding: 5px;
        box-sizing: border-box;
    }

    button {
        padding: 10px;
        cursor: pointer;
    }
</style>

